

/******************************************************************
* An efficient improved group theory-based optimization algorithm *
*            with directed mutation operator                     *
*       for the discounted {0-1} knapsack problem             *
***************************************************************/

/** basd on DKPM2-Bcode**/
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "math.h"
#include "string.h"

#define rdint(i) (rand()%(int)(i))
#define rdft() ((float)rdint(7384))/7383.0
#define rnd(a,b) (rdint((int)(b)-(int)(a)+1)+(int)(a))

#define POPSIZE 20              //population size
#define DIMENSION 5*300          //Dimension of the problem
#define MAXITERA 10*(DIMENSION/3)                //Iterations
#define GERI 30                //Execution times
#define Pr 0.5    //Directed mutation probability
#define MX 2             //[n]=[MX]={0,1,..,MX-1}={0,1}
#define Pm 0.004
#define Pd 0.3


char filename1[] = "test/data/sdkp5.txt";
char filename2[] = "test/bf/sdkp5_bfitness.txt";
char filename3[] = "test/time/sdkp5_time.txt";
char filename4[] = "test/record/sdkp5_rec.txt";

/*************************************************
*      The  definition  of  data  structure      *
*************************************************/
struct indi
{
    int bix[(DIMENSION/3)*2];     //Loading plan, individual position coding
    float fitx;               //The sum of the item values ​​in this loading plan
    int cubage;             //The total weight of the items in this loading plan
} individual[POPSIZE+1],BEST; // Individual data structures

/*************************************************
*     The   definition   of   variables        *
*************************************************/

int BESTS[(DIMENSION/3)*2];
float BESTV=0, BESTW=0;
int WORSTS[(DIMENSION/3)*2];
float WORSTV=999999, WORSTW=999999;
float Mean=0.0;
float arybest[GERI];
float record[GERI+1];//Record intermediate data for drawing convergence curves
float Cvalue[DIMENSION];  //Items profit
float Wvalue[DIMENSION];  //Items weight
int index[DIMENSION];
float KNAPSIZE=0.0;  //Knapsack capacity
float Opt=0.0,alltime=0.0,Std=0.0;
FILE *fp1,*fp2,*fp3;
/*************************************************
*     The   definition   of   fuction          *
*************************************************/
void loadfile(void);
void storefile(void);
void calculateindex(void);
void initialize(void);
void evolution(void);
void greedyoptimization(int num);
void dmo(int num);
int updatefunction(int xp1,int xp2,int xp3);
void mutatefunction(int num);
/************************************************
*            Main        Function               *
************************************************/
main()
{
    int i,m;
    char ch;
    int t=0,generation;
    time_t first,second;
    float usetime;
    for(i=0; i<=GERI; i++)
        record[i]=0;
    loadfile();
    t=0;
    while(t<GERI)

    {
        m=0;
        srand(time(NULL));
        first=clock();
        calculateindex();
        initialize();
        generation=0;
        while(generation<MAXITERA)
        {
            evolution();
            if(generation%(MAXITERA/GERI)==0)
                record[generation/(MAXITERA/GERI)]+= BEST.fitx;
            else if(generation+1==MAXITERA)
                record[GERI]+=BEST.fitx;
            generation++;
        }
        second=clock();
        usetime=(float)(second-first)/CLOCKS_PER_SEC;
        alltime+=usetime;
        arybest[t] = BEST.fitx;
        Mean+=BEST.fitx;
        if(BEST.fitx>BESTV)
        {
            BESTV=BEST.fitx;
            BESTW=BEST.cubage;
            for(i=0; i<(DIMENSION/3)*2; i++)
                BESTS[i]=BEST.bix[i];
        }
        if(BEST.fitx<WORSTV)
        {
            WORSTV=BEST.fitx;
            WORSTW=BEST.cubage;
            for(i=0; i<(DIMENSION/3)*2; i++)
                WORSTS[i]=BEST.bix[i];
        }
        t++;
        printf("%d, ",t);
        printf("BESTfitness : %.2f\n",BEST.fitx);
    }

    storefile();
    exit(0);
}
/********************************************
*        Rate  Sort  by  Increasing         *
********************************************/
void calculateindex(void)
{
    int i,j,pos,temp1;
    double rate[DIMENSION],temp2;

    for(i=0; i<DIMENSION; i++)  //Calculating item profit density
    {
        rate[i]=((double)Cvalue[i])/Wvalue[i];
        index[i]=i;
    }
    for(i=0; i<DIMENSION-1; i++)  // Sorting
    {
        pos=i;
        for(j=i; j<DIMENSION; j++)
            if(rate[pos]<rate[j])
                pos=j;
        temp2=rate[i];
        rate[i]=rate[pos];
        rate[pos]=temp2;
        temp1=index[pos];
        index[pos]=index[i];
        index[i]=temp1;
    }
}
/**************************************************
*         Initialize         Function             *
**************************************************/
void initialize()
{
    int i,j,flg;

    for(i=0; i<POPSIZE; i++)
    {
        for(j=0; j<(DIMENSION/3)*2; j++)
        {
            individual[i].bix[j]=rdint(MX);

        }
        greedyoptimization(i);
    }

    flg=0;
    for(i=1; i<POPSIZE; i++)
    {
        if(individual[i].fitx>individual[flg].fitx)
            flg=i;
    }
    BEST=individual[flg];

}

/********************************************
*    Greedy Strategy to Modify Population   *
********************************************/

void  greedyoptimization(int num) //bD-GROA
{
    int i,k,r;
    float fweight=0,fvalue=0;
    int d=0;
    for(i=0; i<(DIMENSION/3)*2; i+=2) //Determine whether it is an infeasible solution
    {
        d=individual[num].bix[i]*2+individual[num].bix[i+1];
        if(d!=0) fweight = fweight+Wvalue[3*(i/2)+d-1];
    }
    i=DIMENSION-1;
    while(fweight>KNAPSIZE)  //Repair phase
    {
        k = (index[i]/3)*2;
        r = index[i]%3;
        d = individual[num].bix[k]*2+individual[num].bix[k+1];
        if(d==r+1)
        {
            fweight=fweight-Wvalue[index[i]];
            individual[num].bix[k]=0;
            individual[num].bix[k+1]=0;
        }
        i--;
    }
    for(i=0; i<DIMENSION; i++) //Optimization phase
    {
        k = (index[i]/3)*2;
        r = index[i]%3;
        if((individual[num].bix[k]==0)&&(individual[num].bix[k+1]==0)&&(fweight+Wvalue[index[i]]<=KNAPSIZE))
        {
            fweight+=Wvalue[index[i]];
            if(index[i]%3) individual[num].bix[k]=1;
            else individual[num].bix[k]=0;
            if(index[i]%3==1) individual[num].bix[k+1]=0;
            else individual[num].bix[k+1]=1;
        }
    }
    for(i=0; i<(DIMENSION/3)*2; i+=2) //计算适应值
    {
        if(individual[num].bix[i]!=0||individual[num].bix[i+1]!=0)
        {

            d=individual[num].bix[i]*2+individual[num].bix[i+1];
            fvalue+=Cvalue[3*(i/2)+d-1];
        }
    }

    individual[num].fitx=fvalue;
    individual[num].cubage=fweight;



}

/************************************************
*     mutation   and   evolution  operation     *
************************************************/ //GEOA
void evolution(void)
{
    int i,j,r2;
    int p1,p2,p3;
    double r1;
    for(i=0; i<POPSIZE; i++)
    {
        p1=rdint(POPSIZE);
        while(p1==i) p1=rdint(POPSIZE);
        p2=rdint(POPSIZE);
        while((p2==i)||(p2==p1)) p2=rdint(POPSIZE);
        p3=rdint(POPSIZE);
        while((p3==i)||(p3==p1)||(p3==p2)) p3=rdint(POPSIZE);
        for(j=0; j<(DIMENSION/3)*2; j+=2)
        {
            if(rdft()<=0.5) //MbRLCO
            {
                individual[POPSIZE].bix[j]=updatefunction(individual[p1].bix[j],individual[p2].bix[j],individual[p3].bix[j]);
                individual[POPSIZE].bix[j+1]=updatefunction(individual[p1].bix[j+1],individual[p2].bix[j+1],individual[p3].bix[j+1]);

            }
            else
            {
                individual[POPSIZE].bix[j]=individual[i].bix[j];
                individual[POPSIZE].bix[j+1]=individual[i].bix[j+1];
            }
        }
        mutatefunction(POPSIZE);
        dmo(POPSIZE);
        greedyoptimization(POPSIZE);
        if(individual[POPSIZE].fitx>individual[i].fitx)
        {
            individual[i]=individual[POPSIZE];
            if(individual[i].fitx>BEST.fitx)  BEST=individual[i];
        }
    }
}

int updatefunction(int xp1,int xp2,int xp3) //RLCO
//xj=xp1+FS*(xp2-xp3);
{
    int FS,temp;
    if(rdft()<0.33) return(xp1);   //FS=0
    else                           //FS=-1 or FS=1
    {
        if(rdft()<0.5) FS=1;
        else FS=-1;
        if(FS>0) return((xp1+xp2+(MX-xp3))%MX);
        else  return((xp1+MX-(xp2+(MX-xp3))%MX)%MX);
    }
}

void mutatefunction(int num) //bIRMO
{
    int j;
    int x,d;
    for(j=0; j<(DIMENSION/3)*2; j+=2)
    {
        d = individual[num].bix[j]*2+individual[num].bix[j+1];
        if(rdft()<Pm)
        {
            if((rdft()<0.5)&&(d!=0)) // Reverse mutation
            {
                x=4-d;
                individual[num].bix[j]=x/2;
                individual[num].bix[j+1]=x%2;
            }
            else  // Random mutation
            {
                while(d==(x=rdint(4)));
                individual[num].bix[j]=x/2;
                individual[num].bix[j+1]=x%2;
            }
        }

    }

}

void dmo(int num)  //DMO
{
    int i,x;
    for(i=0; i<(DIMENSION/3)*2; i+=2)
        if(individual[num].bix[i]==0&&individual[num].bix[i+1]==0&&rdft()<Pd) // directed mutation
        {
            individual[num].bix[i]=1;
            individual[num].bix[i+1]=1;
        }
}


void loadfile()
{
    int i=0,j=0;

    if((fp1 = fopen(filename1,"r"))==NULL)
    {
        printf("ERROR");
    }
    fscanf(fp1,"%f",&Opt);
    fscanf(fp1,"%f",&KNAPSIZE);
    for(i=0,j=0; i<DIMENSION; i+=3,j++)
    {
        fscanf(fp1,"%f%f%f",&Cvalue[i],&Cvalue[i+1],&Cvalue[i+2]);
    }
    for(i=0,j=0; i<DIMENSION; i+=3,j++)
    {
        fscanf(fp1,"%f%f%f",&Wvalue[i],&Wvalue[i+1],&Wvalue[i+2]);
    }
    fclose(fp1);


}
void storefile()
{
    int i=0;
    float avgTime = 0.0;
    if((fp1 = fopen(filename2,"a"))==NULL)
    {
        printf("ERROR");
        exit(0);
    }
    if((fp2 = fopen(filename3,"a"))==NULL)
    {
        printf("ERROR");
        exit(0);
    }
    if((fp3 = fopen(filename4,"a"))==NULL)
    {
        printf("ERROR");
        exit(0);
    }
    for(i=0; i<=GERI; i++)
    {
        record[i] = record[i]/GERI;
        fprintf(fp3,"%f\n",record[i]);
    }
    Mean = Mean/GERI;
    avgTime = alltime/GERI;
    float temp=0.0;
    for(i=0; i<GERI; i++)
        temp+=(Mean-arybest[i])*(Mean-arybest[i]);
    Std = sqrt(temp/GERI);
    fprintf(fp1,"Opt:%.0f ",Opt);
    fprintf(fp1,"Best:%.0f ",BESTV);
    fprintf(fp1,"Opt/Best:%.4f ",Opt/BESTV);
    fprintf(fp1,"Mean:%.0f ",Mean);
    fprintf(fp1,"Opt/Mean:%.4f ",Opt/Mean);
    fprintf(fp1,"Worst:%.0f ",WORSTV);
    fprintf(fp1,"Opt/Worst:%.4f ",Opt/WORSTV);
    fprintf(fp1,"Std:%.4f \n",Std);
    fprintf(fp2,"avgTime:%.4f \n",avgTime);


    fclose(fp1);
    fclose(fp2);
    fclose(fp3);

}



